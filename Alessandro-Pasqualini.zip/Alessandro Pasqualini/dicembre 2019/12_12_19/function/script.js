function isEven(number){
    if (number % 2 == 0){
        console.log("pari");
    } else{
        console.log("dispari");
    }
}
isEven(2);
isEven(7);