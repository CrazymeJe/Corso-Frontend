function indietro(numero){
    return --numero;
}

console.log(indietro(11));