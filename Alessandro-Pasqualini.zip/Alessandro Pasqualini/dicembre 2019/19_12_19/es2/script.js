$(".zoom").click( function(){
    $("#prima").toggleClass("nascosto")
})
