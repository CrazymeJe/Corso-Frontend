$(document).ready(function(){
    $('.slider').slick({
      
    });
  });